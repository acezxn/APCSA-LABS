import java.util.*;
import java.io.File;

/*
@author: Daniel Lee

final version

An algorithm that solves the Bulls and Cows game

Functionalities:
    1. Manual entry mode: This is a mode that allows the user to evaluate the
    guesses from computer, and use the format _B_C, whereas B represents bulls
    and C represent cows, to describe similarity.
    2. Automated simulation: This is a mode similar to Manual entry mode, but
    instead of allowing the user to answer and potentially make mistakes,
    the code automatically evaluate the guesses from itself and describe it
    using _B_C.
    3. Battle: This mode allows the user to guess the randomly generated secret
    number that will be kept in the program, simulating the actual game. The
    user will always start first, and then the guessing take turns. When the
    user or the program guesses the number correctly, the game ends.
*/

public class Moo {
  // generate all possible secret numbers
  public static ArrayList<String> gen() {
    ArrayList<String> total = new ArrayList<String>();
    for (int th = 0; th < 10; th++) {
      for (int h = 0; h < 10; h++) {
        if (h != th) {
          for (int t = 0; t < 10; t++) {
            if (t != h && t != th) {
              for (int d = 0; d < 10; d++) {
                if (d != t && d != h && d != th) {
                  String str = String.valueOf(th) + String.valueOf(h) + String.valueOf(t) + String.valueOf(d);
                  if (!total.contains(str)) {
                    total.add(str);
                  }
                }
              }
            }
          }
        }
      }
    }
    return total;
  }

  public static boolean checkInput(String num) {

    if (num.length() != 4) {
      return false;
    }
    String used = "";
    for (int i = 0; i < num.length(); i++) {
      if (!Character.isDigit(num.charAt(i))) {
        return false;
      }
      for (int j = 0; j < used.length(); j++) {
        if (num.charAt(i) == used.charAt(j)) {
          return false;
        }
      }
      used += num.charAt(i);
    }
    return true;
  }

  public static boolean validRelation(String rel) {
    return Character.isDigit(rel.charAt(0)) && Character.isDigit(rel.charAt(2)) && rel.charAt(1) == 'B' && rel.charAt(3) == 'C';
  }

  // generate a single secret number
  public static String genSingle() {
    ArrayList<Integer> nums = new ArrayList<Integer>();
    for (int i = 0; i < 10; i++) {
      nums.add(i);
    }
    Collections.shuffle(nums);
    return String.valueOf(nums.get(0)) + String.valueOf(nums.get(1)) + String.valueOf(nums.get(2)) + String.valueOf(nums.get(3));
  }

  // compare two numbers and describe their similarity using _B_C
  public static String compare(String a, String b) {
    int Bs = 0;
    int Cs = 0;
    for (int i = 0; i < a.length(); i++) {
      for (int j = 0; j < b.length(); j++) {
        if (a.charAt(i) == b.charAt(j)) {
          if (i == j) {
            Bs++;
          } else {
            Cs++;
          }
        }
      }
    }
    return Bs + "B" + Cs + "C";
  }



  public static void main(String[] args) {
    Random rand = new Random();
    Scanner input = new Scanner(System.in);
    ArrayList<String> total = gen(); // all possible non repeating 4 digits numbers
    String ans = ""; // the player's secret number
    String secret = ""; // the secret number hold by the computer
    boolean win = false; // whether the player wins
    boolean dontKnow = false; // it will be true if you lie
    int playerGuessCount = 0;
    int programGuessCount = 0;
    int mode = -1;

    // print user manual from manual.txt
    try {
      Scanner manual = new Scanner(new File("manual.txt"));
      while (manual.hasNext()) {
        System.out.println(manual.nextLine());
      }
      manual.close();
    }
    catch(Exception e){
      System.out.println("Unable to locate manual.txt");
    }


    while (true) {
      try
      {
        System.out.println();
        System.out.print("Insert mode (insert integer): ");
        mode = Integer.parseInt(input.nextLine());
        if (mode == 1) {
          System.out.println("\nNow, think of a 4 digit secret number first.");
          System.out.println("When you have one, you may start.");
          System.out.println("CAUTION: If you lie, I'll be unable to guess your number.\n");
          break;
        }
        else if (mode == 2) {
          while (true) {
            System.out.print("Input your secret 4 digits number: ");
            ans = input.nextLine();
            if (checkInput(ans)) {
              break;
            }
            System.out.println("Your input is not valid");
          }
          break;
        }
        else if (mode == 3) {
          // print cow banner from cowBanner.txt
          try {
            Scanner banner = new Scanner(new File("cowBanner.txt"));
            while (banner.hasNext()) {
              System.out.println(banner.nextLine());
            }
            banner.close();
          }
          catch(Exception e){
            System.out.println("Unable to locate cowBanner.txt");
          }

          while (true) {
            System.out.print("Input your secret 4 digits number: ");
            ans = input.nextLine();
            if (checkInput(ans)) {
              break;
            }
            System.out.println("Your input is not valid");
          }

          secret = genSingle();
          System.out.println(secret);
          System.out.println("\nTHE GAME STARTS! GOOD LUCK!\n");
          break;
        }
        else if (mode == 4) {
          try {
            Scanner banner = new Scanner(new File("How.txt"));
            while (banner.hasNext()) {
              System.out.println(banner.nextLine());
            }
            System.out.println();
            banner.close();
          }
          catch(Exception e){
            System.out.println("Unable to locate How.txt");
          }
          break;
        }
        else {
          System.out.println("Invalid input");
          continue;
        }
      } catch(Exception e) {
        ;
      }
      System.out.println("Invalid input");
    }

    if (mode != 4) { // not visiting about page

      while (true) { // Game & Simulation Loop
  /*===========================================================================
  |                                                                           |
  |    Your turn                                                              |
  |                                                                           |
  =============================================================================*/
        if (mode == 3) {
          System.out.println("Your turn\n");
          String guess = "";
          while (true) {
            System.out.print("\tTry to guess a 4 digits number: ");
            guess = input.nextLine();
            if (checkInput(guess)) {
              break;
            }
            System.out.println("Your input is not valid");
          }

          playerGuessCount++;
          String bullCow = compare(guess, secret);
          if (bullCow.equals("4B0C")) {
            win = true;
            break;
          } else {
            System.out.println("\tIt's " + compare(guess, secret) + "\n\n");
           }

        }
  /*===========================================================================
  |                                                                           |
  |    Computer's turn                                                        |
  |                                                                           |
  =============================================================================*/
        if (mode == 3) {
          System.out.println("Computer's turn\n");
        }

        // Generate a guess
        String g = "";
        try {
          int r = rand.nextInt(total.size());
          g = total.get(r);
        }
        catch (Exception e) {
          dontKnow = true;
          break;
        }

        if (mode == 2) {
          System.out.println("\tComputer guesses " + g);
        } else if (mode == 3) {
          System.out.println("\tIs it " + g + "?");
        }
        programGuessCount++;

        // Auto evaluate the guess to _B_C
        String res;
        if (mode == 1) {

          while (true) {
            System.out.println("\t" + g + "? (write in _B_C): ");
            res = input.nextLine();
            if (validRelation(res)) {
              break;
            }
            System.out.println("Invalid input");
          }


        } else {
          res = compare(ans, g);
        }
        System.out.println("\tYou answered: " + res + "\n\n");

        // Process evaluation
        ArrayList<String> new_total = new ArrayList<String>();
        if (res.equals("4B0C")) {
          new_total.add(g);
          total = new_total;
          win = false;
          break;
        }
        for (int i = 0; i < total.size(); i++) {
          String c = total.get(i);
          if (compare(c, g).equals(res)) {
            new_total.add(c);
          }
        }
        total = new_total;
      }

      /*===========================================================================
      |                                                                           |
      |    After game                                                             |
      |                                                                           |
      =============================================================================*/

      if (dontKnow) {
        System.out.println("I don't know! You've probably lied to me.");
      } else {
        if (!win) {
          System.out.println("Your secret number is " + total.get(0) + "!");
        }

        if (mode == 3 && win) {
          System.out.println("YOU WIN! The secret number is " + secret);
          System.out.print("and you take " + playerGuessCount);
          if (playerGuessCount == 1) {
            System.out.println(" trial");
          } else {
            System.out.println(" trials");
          }

        } else if (mode == 3 && !win) {
          System.out.println("YOU LOSE!");
          System.out.print("and the computer takes " + programGuessCount);
          if (programGuessCount == 1) {
            System.out.println(" trial");
          } else {
            System.out.println(" trials");
          }
        } else {
          System.out.print("The computer takes " + programGuessCount);
          if (programGuessCount == 1) {
            System.out.println(" trial");
          } else {
            System.out.println(" trials");
          }
        }
      }
    }
  }
}
